# PRO HDR AI STUDIO — Enhanced Android build

## Included
- Android photo picker (JPG/PNG and supported gallery formats)
- One-tap automatic photo development
- Automatic percentile exposure/levels correction
- Soft highlight roll-off and shadow lift
- Automatic white-balance cast correction
- Restrained vibrance and contrast
- Subtle local sharpening and vignette
- Original/edited preview toggle
- Save high-quality JPEG to Pictures/PRO_HDR_AI_STUDIO
- Offline processing; no account, API key or subscription required

## Important honesty note
This is an advanced **on-device automatic image-processing** starter, not a generative AI photographer and not a full RAW/HDR merge engine. It does not synthesize missing detail, replace skies, segment subjects, perform semantic face retouching, or combine multiple exposures. The algorithm is deliberately restrained and keeps people/clothing/background content intact. Results depend on the source photo.

A genuine cloud AI enhancement pipeline needs a backend service and a paid or quota-limited image model/API. Do not put a private API key inside an Android APK. A secure backend and provider-specific integration must be configured before those AI features can work.

## Build
1. Open this folder in Android Studio (recent stable version).
2. Allow Gradle sync.
3. Run on an Android 8.0+ device or emulator.

Application ID: `com.prohdr.aistudio`
Minimum SDK: 26
