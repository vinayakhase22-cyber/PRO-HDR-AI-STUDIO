package com.prohdr.aistudio

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ImageSearch
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color as UiColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioScreen() }
    }

    private fun savePhoto(bitmap: Bitmap): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "PRO_HDR_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PRO_HDR_AI_STUDIO")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            contentResolver.openOutputStream(uri)?.use {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 97, it)
            } ?: return false
            true
        } catch (_: Exception) { false }
    }

    @Composable
    private fun StudioScreen() {
        var original by remember { mutableStateOf<Bitmap?>(null) }
        var result by remember { mutableStateOf<Bitmap?>(null) }
        var working by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf("अपलोड करा — AI-style प्रो एडिट एका टॅपमध्ये.") }
        val scope = rememberCoroutineScope()

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) scope.launch {
                working = true
                try {
                    val bitmap = withContext(Dispatchers.IO) {
                        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    }
                    original = bitmap
                    result = null
                    message = if (bitmap != null) "फोटो लोड झाला. आता PRO AUTO ENHANCE करा." else "हा फोटो उघडता आला नाही."
                } catch (_: Exception) { message = "फोटो उघडताना अडचण आली." }
                working = false
            }
        }

        MaterialTheme(colorScheme = darkColorScheme(
            primary = UiColor(0xFFD6B15D),
            background = UiColor(0xFF0C0D10),
            surface = UiColor(0xFF191B20)
        )) {
            Column(
                Modifier.fillMaxSize().background(UiColor(0xFF0C0D10)).padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("PRO HDR", color = UiColor(0xFFE4C477), fontSize = 29.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Text("AI PHOTO STUDIO", color = UiColor.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    }
                    Surface(color = UiColor(0xFF29251B), shape = RoundedCornerShape(50)) {
                        Text("PRO ENGINE", color = UiColor(0xFFE4C477), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                    }
                }
                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier.fillMaxWidth().weight(1f).background(UiColor(0xFF191B20), RoundedCornerShape(22.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    val shown = result ?: original
                    if (shown != null) {
                        Image(shown.asImageBitmap(), "Photo preview", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AutoAwesome, null, tint = UiColor(0xFFD6B15D), modifier = Modifier.size(58.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("YOUR PHOTO, REIMAGINED", color = UiColor.White, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("Original फोटो येथे दिसेल", color = UiColor.LightGray, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(message, color = UiColor(0xFFB9BBC2), fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { picker.launch("image/*") },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = UiColor(0xFF252830))
                ) {
                    Icon(Icons.Default.ImageSearch, null); Spacer(Modifier.width(8.dp))
                    Text("फोटो निवडा / बदलावा")
                }
                Spacer(Modifier.height(9.dp))
                Button(
                    onClick = {
                        val src = original
                        if (src != null && !working) scope.launch {
                            working = true
                            message = "PRO ENGINE: exposure • colour • detail • tone mapping..."
                            result = withContext(Dispatchers.Default) { proAutoDevelop(src) }
                            message = "PRO EDIT पूर्ण. Original फोटो बदललेला नाही."
                            working = false
                        }
                    },
                    enabled = original != null && !working,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = UiColor(0xFFD6B15D), contentColor = UiColor(0xFF171717))
                ) {
                    if (working) CircularProgressIndicator(Modifier.size(20.dp), color = UiColor.Black, strokeWidth = 2.dp)
                    else Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(9.dp))
                    Text("PRO AUTO ENHANCE", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(9.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { result = null; message = "Original फोटो दाखवत आहे." },
                        enabled = original != null, modifier = Modifier.weight(1f)
                    ) { Icon(Icons.Default.RestartAlt, null); Spacer(Modifier.width(5.dp)); Text("Original") }
                    Button(
                        onClick = {
                            val bmp = result
                            message = if (bmp != null && savePhoto(bmp)) "फोटो Gallery मध्ये सेव्ह झाला." else "आधी एडिट करा किंवा सेव्ह पुन्हा करा."
                        },
                        enabled = result != null, modifier = Modifier.weight(1f)
                    ) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(5.dp)); Text("Save HD") }
                }
                Spacer(Modifier.height(10.dp))
                Text("AUTO LIGHT  •  SMART COLOUR  •  DETAIL  •  NATURAL LOOK", color = UiColor.Gray, fontSize = 9.sp, letterSpacing = 0.6.sp)
            }
        }
    }
}

/**
 * Local automatic photo development pipeline:
 * percentile exposure normalization, highlight compression, shadow lift,
 * restrained vibrance, warm/cool cast correction, local unsharp detail and vignette.
 * It is deterministic and keeps image geometry/content intact.
 */
private fun proAutoDevelop(src: Bitmap): Bitmap {
    val w = src.width
    val h = src.height
    val n = w * h
    val pixels = IntArray(n)
    src.getPixels(pixels, 0, w, 0, 0, w, h)

    val hist = IntArray(256)
    var avgR = 0.0; var avgG = 0.0; var avgB = 0.0
    for (p in pixels) {
        val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
        val y = (0.2126*r + 0.7152*g + 0.0722*b).roundToInt().coerceIn(0,255)
        hist[y]++
        avgR += r; avgG += g; avgB += b
    }
    avgR /= n; avgG /= n; avgB /= n
    fun percentile(q: Double): Int {
        val target = (n * q).roundToInt().coerceAtLeast(1)
        var sum = 0
        for (i in hist.indices) { sum += hist[i]; if (sum >= target) return i }
        return 255
    }
    val black = percentile(0.008)
    val white = percentile(0.992).coerceAtLeast(black + 8)
    val meanY = 0.2126*avgR + 0.7152*avgG + 0.0722*avgB
    val exposure = (118.0 / meanY.coerceAtLeast(1.0)).coerceIn(0.88, 1.16)
    val castR = ((avgG + avgB) / 2.0 / avgR.coerceAtLeast(1.0)).coerceIn(0.94, 1.06)
    val castB = ((avgR + avgG) / 2.0 / avgB.coerceAtLeast(1.0)).coerceIn(0.94, 1.06)

    val base = IntArray(n)
    for (i in pixels.indices) {
        val p = pixels[i]
        var r = Color.red(p).toDouble()
        var g = Color.green(p).toDouble()
        var b = Color.blue(p).toDouble()
        fun normalize(v: Double): Double {
            val x = ((v - black) / (white - black)).coerceIn(0.0, 1.0)
            val exposed = (x * exposure).coerceIn(0.0, 1.0)
            // Soft shoulder protects bright skies and highlights.
            val shoulder = if (exposed > 0.78) 0.78 + (exposed - 0.78) * 0.62 else exposed
            // Gentle shadow lift without flattening the blacks.
            val shadow = shoulder + 0.055 * (1.0 - shoulder) * (1.0 - shoulder)
            return ((shadow - 0.5) * 1.045 + 0.5).coerceIn(0.0, 1.0) * 255.0
        }
        r = normalize(r) * castR
        g = normalize(g)
        b = normalize(b) * castB
        val lum = 0.2126*r + 0.7152*g + 0.0722*b
        val maxC = max(r, max(g,b)); val minC = min(r, min(g,b))
        val sat = maxC - minC
        val vibrance = 1.13 - (sat / 255.0) * 0.30
        r = lum + (r-lum)*vibrance
        g = lum + (g-lum)*vibrance
        b = lum + (b-lum)*vibrance
        base[i] = Color.argb(Color.alpha(p), r.roundToInt().coerceIn(0,255), g.roundToInt().coerceIn(0,255), b.roundToInt().coerceIn(0,255))
    }

    // Subtle unsharp mask using a 3x3 box blur; edge strength is intentionally restrained.
    val out = IntArray(n)
    for (y in 0 until h) for (x in 0 until w) {
        val idx = y*w+x
        val p = base[idx]
        var sr=0.0; var sg=0.0; var sb=0.0; var count=0
        for (dy in -1..1) for (dx in -1..1) {
            val xx=(x+dx).coerceIn(0,w-1); val yy=(y+dy).coerceIn(0,h-1)
            val q=base[yy*w+xx]
            sr+=Color.red(q); sg+=Color.green(q); sb+=Color.blue(q); count++
        }
        val br=sr/count; val bg=sg/count; val bb=sb/count
        val r=(Color.red(p) + (Color.red(p)-br)*0.42).roundToInt()
        val g=(Color.green(p) + (Color.green(p)-bg)*0.42).roundToInt()
        val b=(Color.blue(p) + (Color.blue(p)-bb)*0.42).roundToInt()
        val nx=(x-w/2.0)/(w/2.0); val ny=(y-h/2.0)/(h/2.0)
        val radius=(nx*nx+ny*ny).coerceAtMost(2.0)
        val vignette=(1.0-0.075*radius).coerceIn(0.84,1.0)
        out[idx]=Color.argb(Color.alpha(p),
            (r*vignette).roundToInt().coerceIn(0,255),
            (g*vignette).roundToInt().coerceIn(0,255),
            (b*vignette).roundToInt().coerceIn(0,255))
    }
    return Bitmap.createBitmap(out,w,h,Bitmap.Config.ARGB_8888)
}
